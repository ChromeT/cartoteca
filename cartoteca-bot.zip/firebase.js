const { initializeApp } = require('firebase/app');
const { getFirestore } = require('firebase/firestore');

// We use the exact same config as the React Web App
const firebaseConfig = {
  apiKey: "AIzaSyBXAjaBrB8eAyMajlCvVJe_9prohjk3EJk",
  authDomain: "cartoteca-666.firebaseapp.com",
  projectId: "cartoteca-666",
  storageBucket: "cartoteca-666.firebasestorage.app",
  messagingSenderId: "49269578015",
  appId: "1:49269578015:web:00375818ad112e0173382a",
  measurementId: "G-4126PD132D"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

console.log('✅ Firebase Client SDK initialized successfully.');

module.exports = { db };
