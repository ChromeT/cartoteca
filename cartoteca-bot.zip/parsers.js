/**
 * Parsers for Karuta Bot Discord Embeds
 * Returns parsed object or null if parsing fails.
 */

function getConditionName(stars) {
  if (stars === '★★★★') return 'Mint';
  if (stars === '★★★☆') return 'Excellent';
  if (stars === '★★☆☆') return 'Good';
  if (stars === '★☆☆☆') return 'Poor';
  if (stars === '☆☆☆☆') return 'Damaged';
  return 'Unknown';
}

// 1. K!V (Card Details)
function parseCardDetails(title, description, image, thumbnail) {
  const kvRegex = /\*\*`([a-z0-9]+)`\*\* · `([★☆]+)` · `#([0-9, ]+)`(?: · `◈([0-9]+)`)? · (.*?) · \*\*(.*?)\*\*/;
  const match = description.match(kvRegex);
  
  if (!match) return null;

  const code = match[1];
  const stars = match[2];
  const print = parseInt(match[3].replace(/[, ]/g, ''));
  const edition = match[4] ? parseInt(match[4]) : 1;
  const series = match[5].trim();
  const name = match[6].trim();
  
  let imageUrl = null;
  if (image && image.url) imageUrl = image.url;
  else if (thumbnail && thumbnail.url) imageUrl = thumbnail.url;

  return {
    code: code,
    print: print,
    edition: edition,
    name: name,
    series: series,
    condition: getConditionName(stars),
    imageUrl: imageUrl,
    isWorker: false,
    isTrade: false,
    notes: '',
    tags: '',
    createdAt: Date.now()
  };
}

// 2. K!WI (Worker Details / Effort)
function parseWorkerDetails(title, description, fields) {
  const effortMatch = description.match(/Effort · \*\*([0-9]+)\*\*/);
  const effort = effortMatch ? parseInt(effortMatch[1]) : null;

  const stats = { toughness: 'F', quickness: 'F', purity: 'F', style: 'F', wellness: 'F', appeal: 'F', grabber: 'F', dropper: 'F', vanity: 'F' };
  
  const codeBlockMatch = description.match(/```js([\s\S]+?)```/);
  if (codeBlockMatch) {
    const lines = codeBlockMatch[1].split('\n');
    lines.forEach(line => {
      const statMatch = line.match(/\(([SABCDEF])\)\s+([A-Za-z]+)/);
      if (statMatch) {
        const grade = statMatch[1];
        const statName = statMatch[2].toLowerCase();
        if (stats[statName] !== undefined) {
          stats[statName] = grade;
        }
      }
    });
  }
  
  return { effort, stats };
}

// 3. K!LU (Character Lookup)
function parseCharacterLookup(title, description, fields) {
  const wishMatch = description.match(/Wishlisted · \*\*([0-9,]+)\*\*/);
  if (wishMatch) {
    return {
      wish: parseInt(wishMatch[1].replace(/,/g, ''))
    };
  }
  return { wish: null };
}

// 4. K!I (Inventory)
function parseInventory(title, description, fields) {
  const inv = { tickets: 0, gold: 0, gems: 0, dust0: 0, dust1: 0, dust2: 0, dust3: 0, dust4: 0 };
  const lines = description.split('\n');
  lines.forEach(line => {
    const match = line.match(/\*\*([0-9,]+)\*\* · `(.*?)`/);
    if (match) {
      const amount = parseInt(match[1].replace(/,/g, ''));
      const type = match[2];
      if (type === 'gold') inv.gold = amount;
      if (type === 'ticket') inv.tickets = amount;
      if (type === 'gem') inv.gems = amount;
      if (type === 'damaged dust') inv.dust0 = amount;
      if (type === 'poor dust') inv.dust1 = amount;
      if (type === 'good dust') inv.dust2 = amount;
      if (type === 'excellent dust') inv.dust3 = amount;
      if (type === 'mint dust') inv.dust4 = amount;
    }
  });
  return inv;
}

// 5. K!UI (User Info)
function parseUserInfo(title, description, fields) {
  let profile = { dropped: 0, grabbed: 0 };
  
  if (fields) {
    const cardsField = fields.find(f => f.name && f.name.includes('Cards'));
    if (cardsField) {
      const lines = cardsField.value.split('\n');
      lines.forEach(line => {
        const match = line.match(/`\s*([0-9,]+)` · (.*)/);
        if (match) {
          const amount = parseInt(match[1].replace(/,/g, ''));
          const desc = match[2].trim();
          if (desc === 'Cards dropped') profile.dropped = amount;
          if (desc === 'Cards grabbed') profile.grabbed = amount;
        }
      });
    }
  }
  return profile;
}

// 6. K!C (Card Collection)
function parseCardCollection(title, description, fields) {
  const cards = [];
  const lines = description.split('\n');
  
  const regex = /(?:.*?(?:`✧([0-9, ]+)` · )?)?\*\*`([a-z0-9]+)`\*\* · `([★☆]+)` · `#([0-9, ]+)`(?: · `◈([0-9]+)`)? · (.*?) · \*\*(.*?)\*\*/;
  
  lines.forEach(line => {
    const match = line.match(regex);
    if (match) {
      const effortStr = match[1];
      const code = match[2];
      const stars = match[3];
      const print = parseInt(match[4].replace(/[, ]/g, ''));
      const edition = match[5] ? parseInt(match[5]) : 1;
      const series = match[6].trim();
      const name = match[7].trim();
      
      cards.push({
        code: code,
        effort: effortStr ? parseInt(effortStr.replace(/[, ]/g, '')) : null,
        print: print,
        edition: edition,
        name: name,
        series: series,
        condition: getConditionName(stars)
      });
    }
  });
  return cards;
}

module.exports = {
  parseCardDetails,
  parseWorkerDetails,
  parseCharacterLookup,
  parseInventory,
  parseUserInfo,
  parseCardCollection
};
