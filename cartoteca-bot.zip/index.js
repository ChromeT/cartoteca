require('dotenv').config();
const { Client, GatewayIntentBits, Partials } = require('discord.js');
const express = require('express');

// Dummy Web Server for Render/Cloud Compatibility
const app = express();
const port = process.env.PORT || 3000;
app.get('/', (req, res) => res.send('Cartoteca Sync Bot is alive and running!'));
app.listen(port, () => console.log(`🌐 Dummy Web Server listening on port ${port}`));

const { db } = require('./firebase');
const parsers = require('./parsers');
const { doc, setDoc, collection, query, where, getDocs, writeBatch } = require('firebase/firestore');

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction],
});

const KARUTA_BOT_ID = process.env.KARUTA_BOT_ID || '646937666251915264';
const FALLBACK_UID = process.env.CARTOTECA_USER_UID;

const pendingCache = new Map();

client.once('ready', () => {
  console.log(`🤖 Logged in as ${client.user.tag}! Multi-User Auto Sync (Client SDK Mode) is active.`);
  if (!db) console.warn('⚠️ Firestore is not initialized.');
});

async function resolveUid(embedDesc) {
  const match = embedDesc.match(/<@(\d+)>/);
  if (match && match[1]) {
    const discordId = match[1];
    if (db) {
      try {
        const q = query(collection(db, 'users'), where('discordId', '==', discordId));
        const snapshot = await getDocs(q);
        if (!snapshot.empty) {
          return snapshot.docs[0].id;
        }
      } catch (err) {
        console.error('Firestore query failed for discordId:', err.message);
      }
    }
  }
  return FALLBACK_UID;
}

client.on('messageCreate', async (message) => {
  if (message.author.id !== KARUTA_BOT_ID) return;
  if (!message.embeds || message.embeds.length === 0) return;

  const embed = message.embeds[0];
  const title = embed.title;
  const desc = embed.description || '';
  
  let success = false;

  try {
    // 1. K!V (Card Details)
    if (title === 'Card Details') {
      const uid = await resolveUid(desc);
      const parsedData = parsers.parseCardDetails(title, desc, embed.image, embed.thumbnail);
      if (parsedData && parsedData.code) {
        pendingCache.set('last_card', { code: parsedData.code, uid: uid });
        if (db && uid) {
          await setDoc(doc(db, 'users', uid, 'cards', parsedData.code), parsedData, { merge: true });
          success = true;
          console.log(`[KV] Synced card ${parsedData.code} for user ${uid}`);
        }
      }
    }
    
    // 2. K!WI (Worker Details)
    else if (title === 'Worker Details') {
      const parsedWorker = parsers.parseWorkerDetails(title, desc, embed.fields);
      const last = pendingCache.get('last_card');
      if (last && db && last.uid) {
        await setDoc(doc(db, 'users', last.uid, 'cards', last.code), parsedWorker, { merge: true });
        success = true;
        console.log(`[KWI] Synced worker stats for card ${last.code} (user ${last.uid})`);
      }
    }
    
    // 3. K!LU (Character Lookup)
    else if (title === 'Character Lookup') {
      const parsedLookup = parsers.parseCharacterLookup(title, desc, embed.fields);
      const last = pendingCache.get('last_card');
      if (last && db && last.uid && parsedLookup.wish !== null) {
        await setDoc(doc(db, 'users', last.uid, 'cards', last.code), { wish: parsedLookup.wish }, { merge: true });
        success = true;
        console.log(`[KLU] Synced wishlist count for card ${last.code}`);
      }
    }
    
    // 4. K!I (Inventory)
    else if (title === null && desc.includes('Items carried by')) {
      const uid = await resolveUid(desc);
      const parsedInv = parsers.parseInventory(title, desc, embed.fields);
      if (db && uid) {
        await setDoc(doc(db, 'users', uid, 'inventory', 'current'), parsedInv);
        success = true;
        console.log(`[KI] Synced inventory for user ${uid}`);
      }
    }
    
    // 5. K!UI (User Info)
    else if (title === null && desc.includes('Showing statistics for')) {
      const uid = await resolveUid(desc);
      const parsedUserInfo = parsers.parseUserInfo(title, desc, embed.fields);
      if (db && uid) {
        await setDoc(doc(db, 'users', uid, 'profile', 'current'), parsedUserInfo, { merge: true });
        success = true;
        console.log(`[KUI] Synced player stats for user ${uid}`);
      }
    }

    // 6. K!C (Card Collection)
    else if (title === null && desc.includes('Cards owned by')) {
      const uid = await resolveUid(desc);
      const parsedCards = parsers.parseCardCollection(title, desc, embed.fields);
      if (parsedCards.length > 0 && db && uid) {
        const batch = writeBatch(db);
        parsedCards.forEach(card => {
          const docRef = doc(db, 'users', uid, 'cards', card.code);
          batch.set(docRef, card, { merge: true });
        });
        await batch.commit();
        success = true;
        console.log(`[KC] Synced ${parsedCards.length} cards for user ${uid}`);
      }
    }
  } catch (error) {
    console.error('Error processing message:', error);
    await message.react('❌').catch(() => {});
    return;
  }

  if (success) {
    await message.react('✅').catch(err => {
      console.warn('Could not add reaction:', err.message);
    });
  }
});

client.login(process.env.DISCORD_BOT_TOKEN).catch((err) => {
  console.error('❌ Failed to login to Discord.', err.message);
});
